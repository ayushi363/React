/**********************************************This line imports the "express" library********************************************************/
let express = require("express");
/*********************************This line creates an instance of the Express Application*****************************************/
let app = express();
/*This line imports the "node-persist" library*/
const storage = require("node-persist");
/*This line imports the "body-parser" library*/
let bodyParser = require("body-parser");
/*This line imports the "cors" middleware*/
const cors = require("cors");
/*This line enables the "cors" middleware for the entire express application*/
app.use(cors());
/*This line creates a JSON parser middleware using body-parser*/
let jsonParser = bodyParser.json();

// ***Asynchronous function that will clear all the data stored in the node-persist when the server restart*****
async function persistStorage() {
  // ************************Initializing the node-persist storage*****************
  await storage.init();

  // **********************Clear all the data stored in the node-persist **********************
  await storage.clear();
}
// *************Calls the "persistStorage" function********************************
persistStorage();

// **********defines a route for handling GET request***************************
app.get("/todolist", async (req, res) => {
  res.send(await storage.keys());
});

// ***********POST request to add item in storage********************
app.post("/todolist", jsonParser, async (req, res) => {
  const { item } = req.body;
  /*stores the extracted item in the node-persist*/
  await storage.setItem(item);
  /*Sends a response indicating that the item was added successfully*/
  res.send("Added item successfully");
});

// **********************Start the server and listen on port no. 5000*****************************
app.listen(5000, function (err) {
  /*Checks if there was an error while starting server*/
  if (err) {
    console.log("Error in server setup");
  } else {
    console.log("Server listening on Port 5000");
  }
});
