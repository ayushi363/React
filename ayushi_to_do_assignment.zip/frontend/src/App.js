/**************************This line imports the "useState" and "useEffect" hooks from the "react" library****************************************/
import { useState, useEffect } from "react";
/*****************************************************This line imports a CSS file********************************************************/
import "./App.css";
/************************************************Functional component of react**********************************************************/
function App() {
  /********************************These lines declares a state variables and its corresponding updater function******************************/
  const [list, setList] = useState([]);
  const [item, setItem] = useState("");

  /************************************* This function will be executed after the component is rendered**********************************/
  useEffect(() => {
    try {
      /********************************Fetching data from the server ***********************************************************************/
      fetch("http://localhost:5000/todolist", {
        method: "GET",
      })
        .then((res) => res.json())
        .then((data) => {
          setList(data);
        });
    } catch (error) {
      console.error(error.message);
    }
  }, []);
  // *****************************************************************This function handles the form submission******************************/
  const onSubmitForm = async (e) => {
    e.preventDefault();
    // ensuring that value should not be blank space
    if (item.trim() === "") {
      alert("Please write something");
    } else {
      try {
        //*********************************************************sending value to database************************************************/
        const body = { item };
        await fetch("http://localhost:5000/todolist", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(body),
        });
        // **********updating the input field*******
        setItem("");

        // ***************************************function fatching tha value from database without refresing the page************************
        await fetch("http://localhost:5000/todolist", {
          method: "GET",
        })
          .then((res) => res.json())
          .then((data) => {
            setList(data);
          });
      } catch (err) {
        console.error(err.message);
      }
    }
  };
  /***************************************This block contains the JSX code that defines the UI of the component****************************/
  return (
    <div className="App">
      <h1>To Do List App</h1>
      <div className="container">
        {/* ********************************************************Input Form****************************************************** */}
        <form className="input-group input-group-l" onSubmit={onSubmitForm}>
          <span className="input-group-text" id="listLabel" name="listName">
            Enter the task:{" "}
          </span>
          {/***************************************Here we use "onChange" event handler that updates the "item" state******************/}
          <input
            type="text"
            name="inputList"
            className="form-control"
            id="inputList"
            placeholder="Get groceries"
            value={item}
            onChange={(event) => setItem(event.target.value)}
            required
          />
          {/************************************************************Submit Button******************************************************/}
          <button
            type="submit"
            className="btn btn-success"
            id="submitButton"
            name="submitButton">
            Add Item
          </button>
        </form>
        <div className="row m-5">
          <div className="col-lg-8 col-md-12 mx-auto">
            {/*****************************Here "list.map" function display each item fetched from the server*******************************/}
            {list.map((listItem) => (
              <input
                key={listItem.id}
                type="text"
                className="form-control text-center mb-3 fw-bold"
                disabled
                value={listItem}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
/******************************************************This exports the "App" component as the default export***********************************/
export default App;
